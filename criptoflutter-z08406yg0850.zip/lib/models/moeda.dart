class Moeda {
  late String icone, nome, sigla;
  late double preco;

  Moeda({
    required this.icone,
    required this.nome,
    required this.sigla,
    required this.preco,
    });
}